<?php

return [
    'pending_status' => 'pending',
    'paginate_count'=>'10'

];
