<?php
return [
    'registerUser' => 'Account registered sucessfuly !',
    'email'=>'Email'
];
