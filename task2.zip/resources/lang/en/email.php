<?php
return [
    'send_email_to' => 'Send Email to :user',
    'recipient_email' => 'Recipient Email',
    'subject' => 'Subject',
    'subject_placeholder' => 'Enter the subject here...',
    'body' => 'Body',
    'body_placeholder' => 'Enter the body of the email here...',
    'send_email' => 'Send Email',

];
