<nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom">
    <div class="container">
        <!-- Logo -->
        <a class="navbar-brand" href="<?php echo e(route('dashboard')); ?>">
            <?php if (isset($component)) { $__componentOriginal8892e718f3d0d7a916180885c6f012e7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8892e718f3d0d7a916180885c6f012e7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => ['class' => 'd-inline-block align-top']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'd-inline-block align-top']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $attributes = $__attributesOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $component = $__componentOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__componentOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
        </a>

        <!-- Hamburger Button for Mobile -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarContent"
            aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Navbar Links -->
        <div class="collapse navbar-collapse" id="navbarContent">
            <ul class="navbar-nav me-auto">
                <!-- Dashboard Link -->
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>"
                        href="<?php echo e(route('dashboard')); ?>">
                        <?php echo e(__('Dashboard')); ?>

                    </a>
                </li>
                <?php if(auth()->check() && auth()->user()->role === 'admin'): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('admin.orders.index') ? 'active' : ''); ?>"
                            href="<?php echo e(route('admin.orders.index')); ?>">
                            <?php echo e(__('Orders')); ?>

                        </a>
                    </li>
                <?php endif; ?>
            </ul>

            <!-- Settings Dropdown -->
            <ul class="navbar-nav  ms-auto pull-right">
                <!-- User Profile -->
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <?php echo e(Auth::user()->name); ?>

                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
                        <a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>"><?php echo e(__('Profile')); ?></a>
                        <div class="dropdown-divider"></div>
                        <!-- Logout -->
                        <form method="POST" action="<?php echo e(route('logout')); ?>" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="dropdown-item">
                                <?php echo e(__('Log Out')); ?>

                            </button>
                        </form>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Responsive Menu -->
<div class="d-lg-none bg-light border-top">
    <div class="container">
        <div class="py-2">
            <a class="d-block text-decoration-none py-1 <?php echo e(request()->routeIs('dashboard') ? 'font-weight-bold' : ''); ?>"
                href="<?php echo e(route('dashboard')); ?>">
                <?php echo e(__('Dashboard')); ?>

            </a>
            <a class="d-block text-decoration-none py-1 <?php echo e(request()->routeIs('admin.orders.index') ? 'font-weight-bold' : ''); ?>"
                href="<?php echo e(route('admin.orders.index')); ?>">
                <?php echo e(__('Orders')); ?>

            </a>
            <a class="d-block text-decoration-none py-1" href="<?php echo e(route('profile.edit')); ?>">
                <?php echo e(__('Profile')); ?>

            </a>
            <!-- Logout -->
            <form method="POST" action="<?php echo e(route('logout')); ?>" class="d-inline">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-link text-decoration-none py-1">
                    <?php echo e(__('Log Out')); ?>

                </button>
            </form>
        </div>
    </div>
</div>
<?php /**PATH E:\freelancer\Rudod Task\New folder\task2\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>