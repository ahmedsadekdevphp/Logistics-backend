<?php $__env->startSection('content'); ?>
    <h1 class="mb-4"><?php echo e(trans('order.orders')); ?></h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success"> <?php echo e(session('success')); ?> </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header">
            <h5 class="card-title mb-0"><?php echo e(trans('order.order_list')); ?></h5>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>#</th>
                            <th><?php echo e(trans('order.user_name')); ?></th>
                            <th><?php echo e(trans('order.order_number')); ?></th>
                            <th><?php echo e(trans('order.pickup_time')); ?></th>
                            <th><?php echo e(trans('order.delivery_time')); ?></th>
                            <th><?php echo e(trans('order.status')); ?></th>
                            <th><?php echo e(trans('order.actions')); ?></th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <?php if($order->user): ?>
                                        <?php echo e($order->user->name); ?>

                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($order->order_no); ?></td>
                                <td><?php echo e($order->pickupTime); ?></td>
                                <td><?php echo e($order->deliveryTime); ?></td>
                                <td>
                                    <?php if($order->lastStatus): ?>
                                        <span class="badge"
                                            style="background-color: <?php echo e($order->lastStatus->statusName->style); ?>;">
                                            <?php echo e($order->lastStatus->statusName->name ?? trans('order.na')); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="badge badge-secondary"><?php echo e(trans('order.no_status')); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin.orders.show', $order->id)); ?>"
                                        class="btn btn-sm btn-info"><?php echo e(trans('order.view')); ?></a>
                                    <a href="<?php echo e(route('admin.users.send-email', $order->id)); ?>"
                                        class="btn btn-sm btn-primary"><?php echo e(trans('order.send_email')); ?></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center"><?php echo e(trans('order.no_orders_found')); ?></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Pagination links -->
        <div class="card-footer">
            <div class="d-flex justify-content-center">
                <?php echo e($orders->links('vendor.pagination.bootstrap-4')); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\freelancer\Rudod Task\New folder\task2\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>