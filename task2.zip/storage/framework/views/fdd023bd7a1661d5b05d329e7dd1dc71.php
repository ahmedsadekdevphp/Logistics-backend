<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($subject); ?></title>
</head>
<body>
    <p><?php echo e($body); ?></p>
    <p><strong>Order Number:</strong> <?php echo e($order->order_no); ?></p>
    <p><strong>Pickup Time:</strong> <?php echo e($order->pickupTime); ?></p>
    <p><strong>Delivery Time:</strong> <?php echo e($order->deliveryTime); ?></p>
</body>
</html>
<?php /**PATH E:\freelancer\Rudod Task\New folder\task2\resources\views/emails/order-status.blade.php ENDPATH**/ ?>