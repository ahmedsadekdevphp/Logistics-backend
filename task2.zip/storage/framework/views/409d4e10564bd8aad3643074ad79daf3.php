<?php $__env->startSection('content'); ?>
    <div class="card mt-20">
        <div class="card-header">
            <h5>
                <center><?php echo e(trans('order.order_details')); ?></center>
            </h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <tbody>
                        <tr>
                            <td><?php echo e(trans('order.order_no')); ?></td>
                            <td><?php echo e($order->order_no); ?></td>
                        </tr>
                        <tr>
                            <td><?php echo e(trans('order.placed_at')); ?></td>
                            <td><?php echo e($order->created_at); ?></td>
                        </tr>
                        <tr>
                            <td><?php echo e(trans('order.location')); ?></td>
                            <td><?php echo e($order->location); ?></td>
                        </tr>
                        <tr>
                            <td><?php echo e(trans('order.size')); ?></td>
                            <td><?php echo e($order->size); ?></td>
                        </tr>
                        <tr>
                            <td><?php echo e(trans('order.weight')); ?></td>
                            <td><?php echo e($order->weight); ?></td>
                        </tr>
                        <tr>
                            <td><?php echo e(trans('order.pickup_time')); ?></td>
                            <td><?php echo e($order->pickupTime); ?></td>
                        </tr>
                        <tr>
                            <td><?php echo e(trans('order.delivery_time')); ?></td>
                            <td><?php echo e($order->deliveryTime); ?></td>
                        </tr>
                        <tr>
                            <td><?php echo e(trans('order.user_name')); ?></td>
                            <td><?php echo e($order->user->name); ?></td>
                        </tr>
                        <tr>
                            <td><?php echo e(trans('order.user_email')); ?></td>
                            <td><?php echo e($order->user->email); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="card mt-20">
        <div class="card-header">
            <h5>
                <center><?php echo e(trans('order.order_status_details')); ?></center>
            </h5>
        </div>
        <div class="card-body">
            <div class="timeline">
                <ul class="timeline-list">
                    <?php $__currentLoopData = $order->statusDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="timeline-item" style="color:<?php echo e($status->statusName->style); ?>;">
                            <div class="timeline-info"> <span><?php echo e($status->created_at->format('Y-m-d H:i:s')); ?></span> </div>
                            <div class="timeline-marker"></div>
                            <i class="fa fa-car"></i>
                            <div class="timeline-content">
                                <h4 class="timeline-title">
                                    <span class="badge" style="background-color: <?php echo e($status->statusName->style); ?>;">
                                        <?php echo e($status->statusName->name); ?>

                                    </span>
                                </h4>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>

    <div class="card mt-20">
        <div class="card-header">
            <h5>
                <center><?php echo e(trans('order.order_status_control')); ?></center>
            </h5>
        </div>
        <div class="card-body pt-100">
            <form action="<?php echo e(route('admin.orders.update', $order->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label for="status"><?php echo e(trans('order.status')); ?></label>
                    <select id="status" name="status" class="form-control">
                        <?php $__currentLoopData = $orderStatues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php echo e($id == $order->lastStatus->order_statuse_id ? 'selected' : ''); ?>>
                                <?php echo e($name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="mt-3">
                    <button type="submit" class="btn btn-primary"><?php echo e(trans('order.update_status')); ?></button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\freelancer\Rudod Task\New folder\task2\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>