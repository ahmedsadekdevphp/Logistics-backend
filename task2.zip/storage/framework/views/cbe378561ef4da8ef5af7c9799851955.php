<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h5 class="mb-4"><?php echo e(trans('email.send_email_to', ['user' => $order->user->name])); ?></h5>
        </div>

        <div class="card-body">
            <form action="<?php echo e(route('admin.users.send-email.post', $order->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="email"><?php echo e(trans('email.recipient_email')); ?></label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo e($order->user->email); ?>"
                        readonly>
                </div>

                <div class="form-group">
                    <label for="subject"><?php echo e(trans('email.subject')); ?></label>
                    <input type="text" class="form-control" id="subject" name="subject"
                        value="Order No:<?php echo e($order->order_no); ?>" placeholder="<?php echo e(trans('email.subject_placeholder')); ?>" required>
                </div>

                <div class="form-group">
                    <label for="body"><?php echo e(trans('email.body')); ?></label>
                    <textarea class="form-control" id="body" name="body" rows="5" placeholder="<?php echo e(trans('email.body_placeholder')); ?>" required></textarea>
                </div>

                <button type="submit" class="btn btn-primary"><?php echo e(trans('email.send_email')); ?></button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\freelancer\Rudod Task\New folder\task2\resources\views/admin/users/send-email.blade.php ENDPATH**/ ?>